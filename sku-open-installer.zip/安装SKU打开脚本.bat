@echo off
chcp 65001 >nul
title SKU 打开脚本安装
echo ================================================
echo   SKU 路径打开器 一键安装
echo   安装后，网页点「打开」即可直接打开共享盘文件夹
echo ================================================
echo.

:: 请求管理员权限
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo 需要管理员权限，正在请求提权...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: 1. 复制打开脚本到固定位置
if not exist "C:\ProgramData\skuo" mkdir "C:\ProgramData\skuo"
copy /y "%~dp0sku_open.ps1" "C:\ProgramData\skuo\sku_open.ps1" >nul 2>&1
if exist "C:\ProgramData\skuo\sku_open.ps1" (
    echo [1/3] 打开脚本已安装
) else (
    echo [失败] 无法复制脚本到 C:\ProgramData\skuo
    goto :fail
)

:: 2. 导入协议注册表
regedit /s "%~dp0sku_open_reg.reg" 2>nul
if %errorlevel% equ 0 (
    echo [2/3] sku-open 协议已注册
) else (
    echo [2/3] 协议注册完成
)

:: 3. 验证
reg query "HKEY_CLASSES_ROOT\sku-open\shell\open\command" >nul 2>&1
if %errorlevel% equ 0 (
    echo [3/3] 验证通过：sku-open 协议已启用
) else (
    echo [警告] 协议验证未通过，请手动以管理员身份运行 sku_open_reg.reg
)

echo.
echo ================================================
echo   安装成功！
echo   现在刷新 SKU 查询网页，点「打开」即可使用
echo   说明：需要电脑能访问共享盘 \\10.10.10.20
echo ================================================
echo.
pause
exit /b 0

:fail
echo.
echo 安装失败，请右键本脚本选择「以管理员身份运行」重试。
echo.
pause
exit /b 1

param(
    [string]$url
)
# SKU 打开器 - 接收 sku-open://open?path=UNC路径 并打开资源管理器
# 由 sku-open 协议调用

$logFile = "$env:TEMP\sku_open.log"
function Write-Log($msg) {
    try { Add-Content -Path $logFile -Value ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg) -ErrorAction SilentlyContinue } catch {}
}

Write-Log ("=== RUN url=" + $url)

try {
    # 解析 url 中的 path 参数
    $path = $null
    if ($url -match "path=([^&]*)") {
        $path = [uri]::UnescapeDataString($Matches[1])
    }

    if (-not $path) {
        # 兜底:去掉协议前缀后整段当路径
        $path = $url -replace '^sku-open://open?', ''
        $path = [uri]::UnescapeDataString($path)
    }

    # Windows 路径: 处理 / 到 \ (协议 URL 里路径可能用了 /)
    $path = $path -replace '/', '\'

    Write-Log ("path parsed: " + $path)

    # 校验路径存在
    if (Test-Path -LiteralPath $path) {
        # 打开文件所在文件夹并选中文件, 或直接打开文件夹
        $item = Get-Item -LiteralPath $path
        if ($item.PSIsContainer) {
            # 是文件夹, 直接打开
            explorer.exe $path
            Write-Log ("OK opened dir: " + $path)
        } else {
            # 是文件, 打开并选中
            explorer.exe /select, $path
            Write-Log ("OK opened file (selected): " + $path)
        }
    } else {
        Write-Log ("PATH NOT FOUND: " + $path)
        # 尝试提示用户路径不可达
        [System.Windows.Forms.MessageBox]::Show("找不到路径:`n$path`n`n请确认已连接到公司内网(共享盘 \\10.10.10.20)", "SKU 打开器", "OK", "Warning") -ErrorAction SilentlyContinue
    }
} catch {
    Write-Log ("ERROR: " + $_.Exception.Message)
    try { [System.Windows.Forms.MessageBox]::Show("打开失败: $($_.Exception.Message)", "SKU 打开器", "OK", "Error") -ErrorAction SilentlyContinue } catch {}
}

@echo off
chcp 65001 >nul
title SKU Open Installer
echo ================================================
echo   SKU Path Opener - One-click Install
echo   After install, click [Open] on the web page
echo ================================================
echo.

:: Request admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Need admin, requesting elevation...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: 1. copy opener script
if not exist "C:\ProgramData\skuo" mkdir "C:\ProgramData\skuo"
copy /y "%~dp0sku_open.ps1" "C:\ProgramData\skuo\sku_open.ps1" >nul 2>&1
if exist "C:\ProgramData\skuo\sku_open.ps1" (
    echo [1/3] opener script installed
) else (
    echo [FAIL] cannot copy script to C:\ProgramData\skuo
    goto :fail
)

:: 2. import protocol registry
regedit /s "%~dp0sku_open_reg.reg" 2>nul
echo [2/3] sku-open protocol registered

:: 3. verify
reg query "HKEY_CLASSES_ROOT\sku-open\shell\open\command" >nul 2>&1
if %errorlevel% equ 0 (
    echo [3/3] verified: sku-open protocol enabled
) else (
    echo [WARN] verify failed, run sku_open_reg.reg manually as admin
)

echo.
echo ================================================
echo   INSTALL SUCCESS!
echo   Open https://lanzier.github.io/sku-search/
echo   Search SKU, click [Open] button
echo   Prereq: can access shared drive \\10.10.10.20
echo ================================================
echo.
pause
exit /b 0

:fail
echo.
echo Install failed. Right-click this file, select Run as administrator.
echo.
pause
exit /b 1

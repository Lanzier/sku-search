param(
    [string]$url
)
# SKU Opener - receives sku-open://open?path=UNC and opens in Explorer
# Called via sku-open protocol

$logFile = "$env:TEMP\sku_open.log"
function Write-Log($msg) {
    try { Add-Content -Path $logFile -Value ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg) -ErrorAction SilentlyContinue } catch {}
}

Write-Log ("=== RUN url=" + $url)

try {
    $path = $null
    if ($url -match "path=([^&]*)") {
        $path = [uri]::UnescapeDataString($Matches[1])
    }
    if (-not $path) {
        $path = $url -replace '^sku-open://open?', ''
        $path = [uri]::UnescapeDataString($path)
    }
    $path = $path -replace '/', '\'
    Write-Log ("path parsed: " + $path)

    if (Test-Path -LiteralPath $path) {
        $item = Get-Item -LiteralPath $path
        if ($item.PSIsContainer) {
            explorer.exe $path
            Write-Log ("OK opened dir: " + $path)
        } else {
            explorer.exe /select, $path
            Write-Log ("OK opened file (selected): " + $path)
        }
    } else {
        Write-Log ("PATH NOT FOUND: " + $path)
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        [System.Windows.Forms.MessageBox]::Show("Path not found: `n$path`n`nPlease make sure you can access the company shared drive (\\10.10.10.20)", "SKU Opener", "OK", "Warning")
    }
} catch {
    Write-Log ("ERROR: " + $_.Exception.Message)
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        [System.Windows.Forms.MessageBox]::Show("Open failed: $($_.Exception.Message)", "SKU Opener", "OK", "Error")
    } catch {}
}
